package com.grocerydriver.app.activity

import android.os.Handler
import android.os.Looper
import com.grocerydriver.app.R
import com.grocerydriver.app.base.BaseActivity
import com.grocerydriver.app.utils.Common
import com.grocerydriver.app.utils.SharePreference
import com.grocerydriver.app.utils.SharePreference.Companion.getBooleanPref


class SplashActivity : BaseActivity() {

    override fun setLayout(): Int {
       return R.layout.activity_splash
    }

    override fun InitView() {
      Handler(Looper.getMainLooper()).postDelayed({
          if(getBooleanPref(this@SplashActivity,SharePreference.isLogin)){
              Common.getLog("getD","Dash")
              openActivity(DashboardActivity::class.java)
              finish()
          }else{
              Common.getLog("getD","Log")
              openActivity(LoginActivity::class.java)
              finish()
          }
        },3000)
    }
}