package com.grocerydriver.app.activity

import android.view.View
import android.webkit.WebViewClient
import com.grocerydriver.app.R
import com.grocerydriver.app.api.ApiClient
import com.grocerydriver.app.base.BaseActivity
import kotlinx.android.synthetic.main.activity_privacypolicy.*

class PrivacyPolicyActivity: BaseActivity() {
    override fun setLayout(): Int = R.layout.activity_privacypolicy

    override fun InitView() {
        tvTitle.text=intent.getStringExtra("privacy_policy")

        ivBack.setOnClickListener {
            finish()
        }

        webView.setWebViewClient(WebViewClient())
        webView.getSettings().setLoadsImagesAutomatically(true)
        webView.getSettings().setJavaScriptEnabled(true)
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY)
        if(intent.getStringExtra("privacy_policy")=="Privacy policy"){
            webView.loadUrl(ApiClient.PrivacyPolicy)
        }else if(intent.getStringExtra("privacy_policy")=="About us"){
            webView.loadUrl(ApiClient.AboutUs)
        }
    }
}