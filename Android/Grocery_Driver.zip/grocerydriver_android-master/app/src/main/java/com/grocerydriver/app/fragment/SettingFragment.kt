package com.grocerydriver.app.fragment

import android.content.Intent
import android.net.Uri
import android.view.View
import com.grocerydriver.app.R
import com.grocerydriver.app.activity.ChangePasswordActivity
import com.grocerydriver.app.activity.DashboardActivity
import com.grocerydriver.app.activity.EditProfileActivity
import com.grocerydriver.app.activity.PrivacyPolicyActivity
import com.grocerydriver.app.base.BaseFragmnet
import com.grocerydriver.app.utils.Common
import com.grocerydriver.app.utils.Common.getCurrentLanguage
import com.grocerydriver.app.utils.SharePreference
import kotlinx.android.synthetic.main.fragment_home.ivMenu
import kotlinx.android.synthetic.main.fragment_setting.*


class SettingFragment: BaseFragmnet() {
    override fun setView(): Int {
        return R.layout.fragment_setting
    }
    override fun Init(view: View) {
        getCurrentLanguage(activity!!,false)
        ivMenu.setOnClickListener {
            (activity as DashboardActivity?)!!.onDrawerToggle()
        }

        cvBtnEditProfile.setOnClickListener {
            openActivity(EditProfileActivity::class.java)
        }

        cvBtnPassword.setOnClickListener {
            openActivity(ChangePasswordActivity::class.java)
        }

        llArabic.setOnClickListener {
            SharePreference.setStringPref(activity!!, SharePreference.SELECTED_LANGUAGE,activity!!.resources.getString(R.string.language_hindi))
            getCurrentLanguage(activity!!, true)
        }

        llEnglish.setOnClickListener {
            SharePreference.setStringPref(activity!!, SharePreference.SELECTED_LANGUAGE,activity!!.resources.getString(R.string.language_english))
            getCurrentLanguage(activity!!, true)
        }

        cvPrivacyPolicy.setOnClickListener {
            startActivity(Intent(activity!!, PrivacyPolicyActivity::class.java).putExtra("privacy_policy","Privacy policy"))
        }


        cvAboutUs.setOnClickListener {
            startActivity(Intent(activity!!,PrivacyPolicyActivity::class.java).putExtra("privacy_policy","About us"))
        }
    }

    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(activity!!,false)
    }


}