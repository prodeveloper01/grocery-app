package com.grocerydriver.app.fragment

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.view.View
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.grocerydriver.app.R
import com.grocerydriver.app.activity.DashboardActivity
import com.grocerydriver.app.activity.OrderDetailActivity
import com.grocerydriver.app.api.ApiClient
import com.grocerydriver.app.api.ListResponceDriverOrder
import com.grocerydriver.app.base.BaseAdaptor
import com.grocerydriver.app.base.BaseFragmnet
import com.grocerydriver.app.model.OrderHistoryModel
import com.grocerydriver.app.utils.Common
import com.grocerydriver.app.utils.Common.alertErrorOrValidationDialog
import com.grocerydriver.app.utils.Common.dismissLoadingProgress
import com.grocerydriver.app.utils.Common.getCurrancy
import com.grocerydriver.app.utils.Common.getDate
import com.grocerydriver.app.utils.Common.showLoadingProgress
import com.grocerydriver.app.utils.SharePreference
import com.grocerydriver.app.utils.SharePreference.Companion.getStringPref
import kotlinx.android.synthetic.main.fragment_orderhistory.*
import kotlinx.android.synthetic.main.fragment_orderhistory.ivMenu
import kotlinx.android.synthetic.main.fragment_orderhistory.swiperefresh
import kotlinx.android.synthetic.main.fragment_orderhistory.tvNoDataFound
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class OrderHistoryFragment : BaseFragmnet() {
    override fun setView(): Int {
        return R.layout.fragment_orderhistory
    }

    override fun Init(view: View) {
        Common.getCurrentLanguage(activity!!,false)
        if (Common.isCheckNetwork(activity!!)) {
            callApiOrderHistory()
        } else {
            alertErrorOrValidationDialog(activity!!, resources.getString(R.string.no_internet))
        }

        ivMenu.setOnClickListener {
            (activity as DashboardActivity?)!!.onDrawerToggle()
        }
        swiperefresh.setOnRefreshListener { // Your code to refresh the list here.
            if (Common.isCheckNetwork(activity!!)) {
                swiperefresh.isRefreshing=false
                callApiOrderHistory()
            } else {
                alertErrorOrValidationDialog(activity!!,resources.getString(R.string.no_internet))
            }
        }
    }

    private fun callApiOrderHistory() {
        showLoadingProgress(activity!!)
        val map = HashMap<String, String>()
        map.put("driver_id", getStringPref(activity!!, SharePreference.userId)!!)
        val call = ApiClient.getClient.getOrderHistory(map)
        call.enqueue(object : Callback<ListResponceDriverOrder> {
            override fun onResponse(
                call: Call<ListResponceDriverOrder>,
                response: Response<ListResponceDriverOrder>
            ) {
                if (response.code() == 200) {
                    dismissLoadingProgress()
                    val restResponce: ListResponceDriverOrder = response.body()!!
                    if (restResponce.getStatus().equals("1")) {
                        if (restResponce.getData().size > 0) {
                            if (isAdded) {
                                rvOrderHistory.visibility = View.VISIBLE
                                tvNoDataFound.visibility = View.GONE
                            }
                            val foodCategoryList = restResponce.getData()
                            setFoodCategoryAdaptor(foodCategoryList)
                        } else {
                            rvOrderHistory.visibility = View.GONE
                            tvNoDataFound.visibility = View.VISIBLE
                        }

                    } else if (restResponce.getStatus().equals("0")) {
                        dismissLoadingProgress()
                        rvOrderHistory.visibility = View.GONE
                        tvNoDataFound.visibility = View.VISIBLE
                    }
                }
            }

            override fun onFailure(call: Call<ListResponceDriverOrder>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    activity!!,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }


    fun setFoodCategoryAdaptor(
        orderHistoryList: ArrayList<OrderHistoryModel>
    ) {
        val orderHistoryAdapter =
            object : BaseAdaptor<OrderHistoryModel>(activity!!, orderHistoryList) {
                @SuppressLint("SetTextI18n", "NewApi")
                override fun onBindData(
                    holder: RecyclerView.ViewHolder?,
                    `val`: OrderHistoryModel,
                    position: Int
                ) {
                    val tvOrderNumber: TextView = holder!!.itemView.findViewById(R.id.tvOrderNumber)
                    val tvPrice: TextView = holder.itemView.findViewById(R.id.tvOrderPrice)
                    val tvOrderStatus: TextView = holder.itemView.findViewById(R.id.tvOrderStatus)
                    val tvPaymentType: TextView = holder.itemView.findViewById(R.id.tvPaymentType)
                    val tvOrderDate: TextView = holder.itemView.findViewById(R.id.tvOrderDate)
                    val tvOrderType: TextView = holder.itemView.findViewById(R.id.tvOrderType)
                    val rlOrder: RelativeLayout = holder.itemView.findViewById(R.id.rlBottom)

                    tvOrderNumber.text = orderHistoryList.get(position).orderNumber.toString()
                    tvPrice.text = getCurrancy(activity!!)+String.format(Locale.US,"%,.2f",orderHistoryList[position].totalPrice!!.toDouble())

                    if(orderHistoryList.get(position).orderType==2){
                        tvOrderType.text="Pickup"
                    }else if(orderHistoryList.get(position).orderType==1){
                        tvOrderType.text="Delivery"
                    }

                    tvPaymentType.text=""

                    if(orderHistoryList.get(position).paymentType!!.toInt()==0){
                        tvOrderType.text = "Cash Payment"
                    }else if(orderHistoryList.get(position).paymentType!!.toInt()==1){
                        tvOrderType.text = "Razorpay Payment"
                    }else if(orderHistoryList.get(position).paymentType!!.toInt()==2){
                        tvOrderType.text = "Stripe Payment"
                    }
                    else {
                        tvOrderType.text = "Wallet Payment"
                    }

                    if(orderHistoryList[position].ordered_date==null){
                        tvOrderDate.text=""
                    }else{
                        tvOrderDate.text=getDate(orderHistoryList[position].ordered_date!!)
                    }

                    if(orderHistoryList.get(position).status==1){
                            rlOrder.backgroundTintList= ColorStateList.valueOf(ResourcesCompat.getColor(resources,R.color.status1,null))
                            tvOrderStatus.text=resources.getString(R.string.order_place)
                        }else if(orderHistoryList.get(position).status==2) {
                            rlOrder.backgroundTintList= ColorStateList.valueOf(ResourcesCompat.getColor(resources,R.color.status2,null))
                            tvOrderStatus.text=resources.getString(R.string.order_ready)
                        }else if(orderHistoryList.get(position).status==3){
                            rlOrder.backgroundTintList= ColorStateList.valueOf(ResourcesCompat.getColor(resources,R.color.status3,null))
                            tvOrderStatus.text=resources.getString(R.string.on_the_way)
                        }else if(orderHistoryList.get(position).status==4){
                            rlOrder.backgroundTintList= ColorStateList.valueOf(ResourcesCompat.getColor(resources,R.color.status4,null))
                            tvOrderStatus.text=resources.getString(R.string.order_delivered)
                        }



                    holder.itemView.setOnClickListener {
                        startActivity(
                            Intent(
                                activity!!,
                                OrderDetailActivity::class.java
                            ).putExtra("order_id",orderHistoryList.get(position).id.toString()).putExtra("status",orderHistoryList.get(position).status.toString())
                        )
                    }
                }

                override fun setItemLayout(): Int {
                    return R.layout.row_orderdelivery
                }

                override fun setNoDataView(): TextView? {
                    return null
                }
            }
        rvOrderHistory.adapter = orderHistoryAdapter
        rvOrderHistory.layoutManager = LinearLayoutManager(activity!!)
        rvOrderHistory.itemAnimator = DefaultItemAnimator()
        rvOrderHistory.isNestedScrollingEnabled = true
    }

    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(activity!!,false)
    }
}