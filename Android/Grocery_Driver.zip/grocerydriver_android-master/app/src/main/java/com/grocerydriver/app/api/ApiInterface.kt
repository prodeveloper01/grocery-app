package com.grocerydriver.app.api

import com.grocerydriver.app.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ApiInterface {
    //Login Api 1
    @POST("driverlogin")
    fun getLogin(@Body map: HashMap<String, String>): Call<RestResponse<LoginModel>>

    //Profile Api 2
    @POST("drivergetprofile")
    fun getProfile(@Body map: HashMap<String, String>): Call<RestResponse<ProfileModel>>

    //EditProfile Api 3
    @Multipart
    @POST("drivereditprofile")
    fun setProfile(@Part("user_id") userId: RequestBody,@Part("name") name: RequestBody, @Part profileimage: MultipartBody.Part?): Call<SingleResponse>

    //Chnage Password  Api 4
    @POST("driverchangepassword")
    fun setChangePassword(@Body map: HashMap<String, String>):Call<SingleResponse>

    //forgotPassword Api 5
    @POST("driverforgotPassword")
    fun setforgotPassword(@Body map: HashMap<String, String>):Call<SingleResponse>

    //driverorder  Api 6
    @POST("driverorder")
    fun getOrderHistory(@Body map: HashMap<String, String>):Call<ListResponceDriverOrder>

    //OrderDetail Api 7
    @POST("driverorderdetails")
    fun setgetOrderDetail(@Body map: HashMap<String, String>):Call<RestOrderDetailResponse>

    //Chnage Password  Api 8
    @POST("delivered")
    fun setOrderDeliver(@Body map: HashMap<String, String>):Call<SingleResponse>

    //Chnage Password  Api 8
    @POST("driverongoingorder")
    fun setOnGoingOrder(@Body map: HashMap<String, String>):Call<ListResponceDriverOrder>
}