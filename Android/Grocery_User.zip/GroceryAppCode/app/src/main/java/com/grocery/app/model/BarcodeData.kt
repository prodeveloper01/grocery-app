package com.grocery.app.model

import com.google.gson.annotations.SerializedName

data class BarcodeData(

	@field:SerializedName("id")
	val id: Int? = null
)
