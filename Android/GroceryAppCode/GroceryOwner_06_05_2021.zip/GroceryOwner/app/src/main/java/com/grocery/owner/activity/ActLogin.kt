package com.grocery.owner.activity

import android.content.Intent
import android.widget.TextView
import com.google.firebase.FirebaseApp
import com.google.firebase.iid.FirebaseInstanceId
import com.grocery.owner.R
import com.grocery.owner.api.ApiClient
import com.grocery.owner.api.RestResponse
import com.grocery.owner.base.BaseActivity
import com.grocery.owner.model.LoginModel
import com.grocery.owner.utils.Common
import com.grocery.owner.utils.Common.alertErrorOrValidationDialog
import com.grocery.owner.utils.Common.dismissLoadingProgress
import com.grocery.owner.utils.Common.getLog
import com.grocery.owner.utils.Common.showLoadingProgress
import com.grocery.owner.utils.SharePreference
import com.grocery.owner.utils.SharePreference.Companion.setStringPref
import com.grocery.owner.utils.SharePreference.Companion.userEmail
import com.grocery.owner.utils.SharePreference.Companion.userId
import com.grocery.owner.utils.SharePreference.Companion.userMobile
import kotlinx.android.synthetic.main.act_login.*
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ActLogin : BaseActivity() {
    var strToken=""

    override fun setLayout(): Int = R.layout.act_login

    override fun InitView() {
        Common.getCurrentLanguage(this@ActLogin, false)

        FirebaseApp.initializeApp(this@ActLogin)
        strToken= FirebaseInstanceId.getInstance().token.toString()
        getLog("Token== ",strToken)
        getLog("Lang ", SharePreference.getStringPref(this@ActLogin, SharePreference.SELECTED_LANGUAGE)!!)
        val tvLogin = findViewById<TextView>(R.id.tvLogin)

        tvLogin.setOnClickListener {
            if (edEmail.text.toString() == "") {
                alertErrorOrValidationDialog(
                    this@ActLogin,
                    resources.getString(R.string.validation)
                )
            } else if (!Common.isValidEmail(edEmail.text.toString())) {
                alertErrorOrValidationDialog(
                    this@ActLogin,
                    resources.getString(R.string.validation_valid_email)
                )
            } else if (edPassword.text.toString() == "") {
                alertErrorOrValidationDialog(
                    this@ActLogin,
                    resources.getString(R.string.validation)
                )
            } else {
                val hasmap = HashMap<String, String>()
                hasmap["email"] = edEmail.text.toString()
                hasmap["password"] = edPassword.text.toString()
                hasmap["token"] = strToken
                if (Common.isCheckNetwork(this@ActLogin)) {
                    callApiLogin(hasmap)
                } else {
                    alertErrorOrValidationDialog(
                        this@ActLogin,
                        resources.getString(R.string.no_internet)
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(this@ActLogin, false)

    }

    private fun callApiLogin(hasmap: HashMap<String, String>) {
        showLoadingProgress(this@ActLogin)
        val call = ApiClient.getClient.login(hasmap)
        call.enqueue(object : Callback<RestResponse<LoginModel>> {
            override fun onResponse(
                call: Call<RestResponse<LoginModel>>,
                response: Response<RestResponse<LoginModel>>
            ) {
                if (response.code() == 200) {
                    val loginResponce: RestResponse<LoginModel> = response.body()!!
                    if (loginResponce.status == 1) {
                        dismissLoadingProgress()
                        val loginModel: LoginModel? = loginResponce.data
                        SharePreference.setBooleanPref(this@ActLogin, SharePreference.isLogin, true)
                        setStringPref(this@ActLogin, userId, loginModel?.id.toString())
                        setStringPref(this@ActLogin, userMobile, loginModel?.mobile.toString())
                        setStringPref(this@ActLogin, userEmail, loginModel?.email.toString())
                        val intent = Intent(this@ActLogin, ActDashBoard::class.java)
                        intent.flags =
                            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        finish()
                        finishAffinity()
                    } else if (loginResponce.status == 0) {
                        dismissLoadingProgress()
                        alertErrorOrValidationDialog(
                            this@ActLogin,
                            loginResponce.message
                        )
                    }
                } else {
                    val error = JSONObject(response.errorBody()!!.string())
                    dismissLoadingProgress()
                    alertErrorOrValidationDialog(
                        this@ActLogin,
                        error.getString("message")
                    )
                }
            }

            override fun onFailure(call: Call<RestResponse<LoginModel>>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    this@ActLogin,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }

}