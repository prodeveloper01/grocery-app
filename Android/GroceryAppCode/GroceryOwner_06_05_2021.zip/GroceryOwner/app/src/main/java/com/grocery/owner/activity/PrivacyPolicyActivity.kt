package com.grocery.owner.activity

import android.view.View
import android.webkit.WebViewClient
import com.grocery.owner.R
import com.grocery.owner.api.ApiClient
import com.grocery.owner.base.BaseActivity
import com.grocery.owner.utils.SharePreference

import kotlinx.android.synthetic.main.activity_privacy_policy.*

class PrivacyPolicyActivity: BaseActivity() {
    override fun setLayout(): Int = R.layout.activity_privacy_policy
    override fun InitView() {
        tvTitle.text = intent.getStringExtra("privacy_policy")

        ivBack.setOnClickListener {
            finish()
        }
        if(SharePreference.getStringPref(this@PrivacyPolicyActivity, SharePreference.SELECTED_LANGUAGE).equals(resources.getString(R.string.language_hindi))){
            ivBack.rotation= 180F
        }else{
            ivBack.rotation= 0F
        }
        webView.webViewClient = WebViewClient()
        webView.settings.loadsImagesAutomatically = true
        webView.settings.javaScriptEnabled = true
        webView.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
        if (intent.getStringExtra("privacy_policy") == "Privacy policy") {
            webView.loadUrl(ApiClient.PrivacyPolicy)
        } else if (intent.getStringExtra("privacy_policy") == "About us") {
            webView.loadUrl(ApiClient.AboutUs)
        }

    }
}