package com.grocery.owner.fragments

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import androidx.annotation.RequiresApi
import com.grocery.owner.R
import com.grocery.owner.activity.ActDashBoard
import com.grocery.owner.activity.ChangePasswordActivity
import com.grocery.owner.activity.PrivacyPolicyActivity
import com.grocery.owner.base.BaseFragmnet
import com.grocery.owner.utils.Common
import com.grocery.owner.utils.Common.getCurrentLanguage
import com.grocery.owner.utils.SharePreference
import kotlinx.android.synthetic.main.frag_home.ivMenu
import kotlinx.android.synthetic.main.frag_settings.*


class FragSettings : BaseFragmnet() {
    override fun setView(): Int = R.layout.frag_settings

    override fun Init(view: View) {

        ivMenu.setOnClickListener {
            (activity as ActDashBoard?)?.onDrawerToggle()
        }

        cvPolicy?.setOnClickListener {
            startActivity(
                Intent(
                    activity!!,
                    PrivacyPolicyActivity::class.java
                ).putExtra("privacy_policy", "Privacy policy")
            )
        }

        cvAboutUs?.setOnClickListener {
            startActivity(
                Intent(
                    activity!!,
                    PrivacyPolicyActivity::class.java
                ).putExtra("privacy_policy", "About us")
            )

        }

        cvBtnChangePassword?.setOnClickListener {
            startActivity(Intent(activity!!, ChangePasswordActivity::class.java))
        }


        cvLanguage?.setOnClickListener {
            changeLanguageDialog(requireActivity())
        }



    }


    @SuppressLint("NewApi")
    private fun changeLanguageDialog(act: Activity) {
        var dialog: Dialog? = null
        try {
            if (dialog != null) {
                dialog.dismiss()
                dialog = null
            }
            dialog = Dialog(act, R.style.AppCompatAlertDialogStyleBig)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT
            );
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCancelable(true)
            val mInflater = LayoutInflater.from(act)
            val mView = mInflater.inflate(R.layout.dialog_language, null, false)
            val tvLtr: TextView = mView.findViewById(R.id.tvLtr)
            val tvRtl: TextView = mView.findViewById(R.id.tvRtl)

            tvLtr.setOnClickListener {
                SharePreference.setStringPref(
                    requireActivity(),
                    SharePreference.SELECTED_LANGUAGE,
                    requireActivity().resources.getString(R.string.language_english)
                )
                getCurrentLanguage(requireActivity(), true)
            }

            tvRtl.setOnClickListener {
                SharePreference.setStringPref(
                    requireActivity(),
                    SharePreference.SELECTED_LANGUAGE,
                    requireActivity().resources.getString(R.string.language_hindi)
                )
                getCurrentLanguage(requireActivity(), true)
            }

            dialog.setContentView(mView)
            dialog.show()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }


    @SuppressLint("NewApi")
    override fun onResume() {
        super.onResume()
        getCurrentLanguage(requireActivity(), false)

    }


}