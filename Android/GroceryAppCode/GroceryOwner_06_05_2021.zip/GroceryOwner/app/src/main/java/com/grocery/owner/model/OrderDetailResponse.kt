package com.grocery.owner.model

import com.google.gson.annotations.SerializedName

data class OrderDetailResponse(

	@field:SerializedName("pincode")
	val pincode: String? = null,

	@field:SerializedName("delivery_address")
	val deliveryAddress: String? = null,

	@field:SerializedName("data")
	val data: ArrayList<OrderDataItem>? = null,

	@field:SerializedName("order_number")
	val orderNumber: String? = null,

	@field:SerializedName("mobile")
	val mobile: String? = null,

	@field:SerializedName("message")
	val message: String? = null,

	@field:SerializedName("summery")
	val summery: Summery? = null,

	@field:SerializedName("building")
	val building: String? = null,

	@field:SerializedName("profile_image")
	val profileImage: String? = null,

	@field:SerializedName("name")
	val name: String? = null,

	@field:SerializedName("landmark")
	val landmark: String? = null,

	@field:SerializedName("lang")
	val lang: String? = null,

	@field:SerializedName("order_type")
	val orderType: String? = null,

	@field:SerializedName("lat")
	val lat: String? = null,

	@field:SerializedName("status")
	val status: Int? = null
)

data class Summery(

	@field:SerializedName("user_email")
	val userEmail: String? = null,

	@field:SerializedName("order_notes")
	val orderNotes: String? = null,

	@field:SerializedName("discount_amount")
	val discountAmount: String? = null,

	@field:SerializedName("user_name")
	val userName: String? = null,

	@field:SerializedName("driver_mobile")
	val driverMobile: Any? = null,

	@field:SerializedName("promocode")
	val promocode: String? = null,

	@field:SerializedName("tax")
	val tax: String? = null,

	@field:SerializedName("driver_profile_image")
	val driverProfileImage: Any? = null,

	@field:SerializedName("driver_name")
	val driverName: String? = null,

	@field:SerializedName("order_status")
	val orderStatus: String? = null,

	@field:SerializedName("delivery_charge")
	val deliveryCharge: String? = null,

	@field:SerializedName("user_profile_image")
	val userProfileImage: String? = null,

	@field:SerializedName("user_mobile")
	val userMobile: String? = null,

	@field:SerializedName("order_total")
	val orderTotal: String? = null
)

data class OrderDataItem(

	@field:SerializedName("itemimage")
	val itemimage: String? = null,

	@field:SerializedName("item_id")
	val itemId: String? = null,

	@field:SerializedName("item_price")
	val itemPrice: String? = null,

	@field:SerializedName("qty")
	val qty: String? = null,

	@field:SerializedName("weight")
	val weight: String? = null,

	@field:SerializedName("item_name")
	val itemName: String? = null,

	@field:SerializedName("id")
	val id: Int? = null
)
