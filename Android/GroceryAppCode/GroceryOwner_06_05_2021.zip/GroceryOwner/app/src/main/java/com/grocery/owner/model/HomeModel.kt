package com.grocery.owner.model

import com.google.gson.annotations.SerializedName

data class HomeModel(

	@field:SerializedName("todayorders")
	val todayorders: ArrayList<TodayordersItem>? = null,

	@field:SerializedName("message")
	val message: String? = null,

	@field:SerializedName("total_orders")
	val totalOrders: Int? = null,

	@field:SerializedName("currency")
	val currency: String? = null,

	@field:SerializedName("cancelled_order")
	val cancelledOrder: Int? = null,

	@field:SerializedName("latest_order")
	val latestOrder: String? = null,

	@field:SerializedName("status")
	val status: Int? = null,

	@field:SerializedName("earning")
	val earning: String? = null
)

data class TodayordersItem(

	@field:SerializedName("date")
	val date: String? = null,

	@field:SerializedName("payment_type")
	val paymentType: String? = null,

	@field:SerializedName("total_price")
	val totalPrice: String? = null,

	@field:SerializedName("order_number")
	val orderNumber: String? = null,

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("order_type")
	val orderType: String? = null,

	@field:SerializedName("users")
	val users: Any? = null,

	@field:SerializedName("status")
	val status: String? = null
)
