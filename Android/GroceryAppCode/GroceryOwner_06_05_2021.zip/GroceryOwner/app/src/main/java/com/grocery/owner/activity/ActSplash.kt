package com.grocery.owner.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.grocery.owner.R
import com.grocery.owner.base.BaseActivity
import com.grocery.owner.utils.SharePreference
import com.grocery.owner.utils.SharePreference.Companion.getBooleanPref

class ActSplash : BaseActivity() {
    override fun setLayout(): Int = R.layout.act_splash

    override fun InitView() {


        Handler(Looper.getMainLooper()).postDelayed({

            if(getBooleanPref(this@ActSplash, SharePreference.isLogin)){
                openActivity(ActDashBoard::class.java)
                finish()
            }else {
                openActivity(ActLogin::class.java)
                finish()
            }
        },3000)
    }

}