package com.grocery.owner.api

import com.grocery.owner.model.*
import com.grocery.app.api.SingleResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiInterface {

    @POST("adminlogin")
    fun login(@Body hashMap: HashMap<String,String>): Call<RestResponse<LoginModel>>


    @POST("home")
    fun getHomeDetail(@Body hashMap: HashMap<String,String>): Call<HomeModel>


    @POST("changepassword")
    fun setChangePassword(@Body map: HashMap<String, String>):Call<SingleResponse>

    @POST("update")
    fun update(@Body map: HashMap<String, String>):Call<SingleResponse>

    @POST("ordercancel")
    fun orderCancel(@Body map: HashMap<String, String>):Call<SingleResponse>

    @POST("orderdetails")
    fun orderDetails(@Body map: HashMap<String, String>):Call<OrderDetailResponse>

    @POST("history")
    fun orderHistory(@Body map: HashMap<String, String>):Call<HistoryResponse>

    @POST("assign")
    fun assignOrder(@Body map: HashMap<String, String>):Call<SingleResponse>

    @GET("drivers")
    fun getDrivers():Call<ListResponse<DriverModel>>

}