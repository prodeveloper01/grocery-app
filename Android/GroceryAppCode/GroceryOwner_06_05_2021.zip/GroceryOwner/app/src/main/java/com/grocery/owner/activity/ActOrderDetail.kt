package com.grocery.owner.activity

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.grocery.owner.R
import com.grocery.owner.api.ApiClient
import com.grocery.owner.api.ListResponse
import com.grocery.owner.base.BaseActivity
import com.grocery.owner.base.BaseAdaptor
import com.grocery.owner.model.*
import com.grocery.owner.utils.Common
import com.grocery.owner.utils.Common.alertErrorOrValidationDialog
import com.grocery.owner.utils.Common.dismissLoadingProgress
import com.grocery.owner.utils.Common.getCurrancy
import com.grocery.owner.utils.Common.getCurrency
import com.grocery.owner.utils.Common.showLoadingProgress
import com.grocery.owner.utils.SharePreference
import com.grocery.owner.utils.SharePreference.Companion.userId
import com.bumptech.glide.Glide
import com.grocery.app.api.SingleResponse
import kotlinx.android.synthetic.main.act_order_detail.*
import kotlinx.android.synthetic.main.row_driver_list.*
import kotlinx.android.synthetic.main.row_orderdelivery.*
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.collections.HashMap

class ActOrderDetail : BaseActivity() {
    private var orderId = ""
    private var orderStatus = 0
    private val driverId = ""
    private var OrderTotal: Double = 0.0
    private var dialog: Dialog? = null

    override fun setLayout(): Int = R.layout.act_order_detail

    override fun InitView() {

        Common.getCurrentLanguage(this@ActOrderDetail, false)
        if(SharePreference.getStringPref(this@ActOrderDetail, SharePreference.SELECTED_LANGUAGE).equals(resources.getString(R.string.language_hindi))){
            ivBack.rotation= 180F
        }else{
            ivBack.rotation= 0F
        }
        orderId = intent.getStringExtra("order_id") ?: ""
        orderStatus = intent.getStringExtra("order_status")?.toInt()!!
        if (Common.isCheckNetwork(this@ActOrderDetail)) {
            callApiOrderDetail()
        } else {
            alertErrorOrValidationDialog(
                this@ActOrderDetail,
                resources.getString(R.string.no_internet)
            )
        }
        ivBack.setOnClickListener {
            finish()
        }


        btnOrderCancelled?.setOnClickListener {
            if (Common.isCheckNetwork(this@ActOrderDetail)) {
                val hashMap = HashMap<String, String>()
                hashMap["order_id"] = orderId
                callApiCancelOrder(hashMap)
            } else {
                alertErrorOrValidationDialog(
                    this@ActOrderDetail,
                    resources.getString(R.string.no_internet)
                )
            }
        }


    }

    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(this@ActOrderDetail, false)

    }

    override fun onPause() {
        super.onPause()
        Common.getCurrentLanguage(this@ActOrderDetail, false)

    }
    private fun openGetDriverList() {
        dialog = Dialog(this@ActOrderDetail)
        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.setCancelable(false)
        val lp = WindowManager.LayoutParams()
        lp.windowAnimations = R.style.DialogAnimation
        dialog?.window!!.attributes = lp
        dialog?.setContentView(R.layout.dlg_get_driver)
        dialog?.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog?.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val ivCancel = dialog?.findViewById<ImageView>(R.id.ivCancel)
        val rvDriverList = dialog?.findViewById<RecyclerView>(R.id.rvDriverList)
        val tvNoDataFound = dialog?.findViewById<TextView>(R.id.tvNoDataFound)

        callGetDriversApi(rvDriverList!!, tvNoDataFound!!)
        ivCancel?.setOnClickListener {
            dialog?.dismiss()
        }
        dialog?.show()
    }

    private fun callGetDriversApi(rvDriverList: RecyclerView, tvNoDataFound: TextView) {
        showLoadingProgress(this@ActOrderDetail)
        val call = ApiClient.getClient.getDrivers()
        call.enqueue(object : Callback<ListResponse<DriverModel>> {
            override fun onResponse(
                call: Call<ListResponse<DriverModel>>,
                response: Response<ListResponse<DriverModel>>
            ) {
                if (response.code() == 200) {
                    dismissLoadingProgress()
                    val restResponce: ArrayList<DriverModel>? = response.body()?.data
                    if (restResponce?.size!! > 0) {
                        rvDriverList.visibility = View.VISIBLE
                        tvNoDataFound.visibility = View.GONE

                        setDriverAdapter(restResponce, rvDriverList)
                    } else {
                        tvNoDataFound.visibility = View.VISIBLE
                        rvDriverList.visibility = View.GONE
                    }
                } else {
                    dismissLoadingProgress()
                    alertErrorOrValidationDialog(this@ActOrderDetail, response.message())
                    tvNoDataFound.visibility = View.VISIBLE
                    rvDriverList.visibility = View.GONE
                }

            }

            override fun onFailure(call: Call<ListResponse<DriverModel>>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    this@ActOrderDetail,
                    resources.getString(R.string.error_msg)
                )
                tvNoDataFound.visibility = View.VISIBLE
                rvDriverList.visibility = View.GONE
            }
        })
    }


    private fun callUpdateOrder(hashMap: HashMap<String, String>) {
        showLoadingProgress(this@ActOrderDetail)
        val call = ApiClient.getClient.update(hashMap)
        call.enqueue(object : Callback<SingleResponse> {
            override fun onResponse(
                call: Call<SingleResponse>,
                response: Response<SingleResponse>
            ) {
                if (response.code() == 200) {
                    dismissLoadingProgress()
                    val i =Intent(this@ActOrderDetail,ActDashBoard::class.java)
                    setResult(200,i)
                    finish()
                } else {
                    dismissLoadingProgress()
                    alertErrorOrValidationDialog(this@ActOrderDetail, response.message())

                }

            }

            override fun onFailure(call: Call<SingleResponse>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    this@ActOrderDetail,
                    resources.getString(R.string.error_msg)
                )

            }
        })
    }

    private fun setDriverAdapter(driverList: ArrayList<DriverModel>, rvDriverList: RecyclerView) {
        val orderHistoryAdapter =
            object : BaseAdaptor<DriverModel>(this@ActOrderDetail, driverList) {
                @SuppressLint("SetTextI18n", "NewApi")
                override fun onBindData(
                    holder: RecyclerView.ViewHolder?,
                    `val`: DriverModel,
                    position: Int
                ) {

                    val tvDriverName = holder?.itemView?.findViewById<TextView>(R.id.tvDriverName)
                    val tvDriverEmail = holder?.itemView?.findViewById<TextView>(R.id.tvDriverEmail)
                    val ivProfile = holder?.itemView?.findViewById<ImageView>(R.id.ivProfile)
                    tvDriverName?.text = driverList[position].name
                    tvDriverEmail?.text = driverList[position].email
                    ivProfile?.let {
                        Glide.with(this@ActOrderDetail).load(driverList[position].image)
                            .placeholder(resources.getDrawable(R.drawable.ic_placeholder))
                            .centerCrop()
                            .into(it)
                    }
                    holder?.itemView?.setOnClickListener {
                        dialog?.dismiss()
                        if (Common.isCheckNetwork(this@ActOrderDetail)) {
                            val hashMap = HashMap<String, String>()
                            hashMap["order_id"] = orderId
                            hashMap["driver_id"] = driverList[position].id.toString()
                            callApiAssignOrder(hashMap)
                        } else {
                            alertErrorOrValidationDialog(
                                this@ActOrderDetail,
                                resources.getString(R.string.no_internet)
                            )
                        }
                    }
                }

                override fun setItemLayout(): Int {
                    return R.layout.row_driver_list
                }

            }
        rvDriverList.adapter = orderHistoryAdapter
        rvDriverList.layoutManager = LinearLayoutManager(this@ActOrderDetail)
        rvDriverList.itemAnimator = DefaultItemAnimator()
        rvDriverList.isNestedScrollingEnabled = true
    }


    private fun callApiOrderDetail() {
        showLoadingProgress(this@ActOrderDetail)
        val map = java.util.HashMap<String, String>()
        map["order_id"] = intent.getStringExtra("order_id")!!
        map["user_id"] = SharePreference.getStringPref(this@ActOrderDetail, userId).toString()

        val call = ApiClient.getClient.orderDetails(map)
        call.enqueue(object : Callback<OrderDetailResponse> {
            override fun onResponse(
                call: Call<OrderDetailResponse>,
                response: Response<OrderDetailResponse>
            ) {
                if (response.code() == 200) {
                    dismissLoadingProgress()
                    val restResponce: OrderDetailResponse = response.body()!!
                    if (restResponce.status == 1) {
                        setFoodDetailData(restResponce)
                    } else if (restResponce.status == 0) {
                        dismissLoadingProgress()
                        rvOrderItemFood.visibility = View.GONE
                    }
                } else {
                    dismissLoadingProgress()
                    alertErrorOrValidationDialog(
                        this@ActOrderDetail,
                        resources.getString(R.string.error_msg)
                    )
                }
            }

            override fun onFailure(call: Call<OrderDetailResponse>, t: Throwable) {
                dismissLoadingProgress()
                t.printStackTrace()
                alertErrorOrValidationDialog(
                    this@ActOrderDetail,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }


    private fun callApiCancelOrder(map: java.util.HashMap<String, String>) {
        showLoadingProgress(this@ActOrderDetail)
        val call = ApiClient.getClient.orderCancel(map)
        call.enqueue(object : Callback<SingleResponse> {
            override fun onResponse(
                call: Call<SingleResponse>,
                response: Response<SingleResponse>
            ) {
                if (response.code() == 200) {
                    val restResponse: SingleResponse = response.body()!!
                    if (restResponse.status == 1) {
                        dismissLoadingProgress()
                        Common.isCancelledOrder = true
                        val i =Intent(this@ActOrderDetail,ActOrderDetail::class.java)
                        setResult(200,i)
                        finish()
                    } else if (restResponse.status == 0) {
                        dismissLoadingProgress()
                        alertErrorOrValidationDialog(
                            this@ActOrderDetail,
                            restResponse.message
                        )
                    }
                } else {
                    val error = JSONObject(response.errorBody()!!.string())
                    dismissLoadingProgress()
                    alertErrorOrValidationDialog(
                        this@ActOrderDetail,
                        error.getString("message")
                    )
                }
            }

            override fun onFailure(call: Call<SingleResponse>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    this@ActOrderDetail,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }


    private fun callApiAssignOrder(map: java.util.HashMap<String, String>) {
        showLoadingProgress(this@ActOrderDetail)
        val call = ApiClient.getClient.assignOrder(map)
        call.enqueue(object : Callback<SingleResponse> {
            override fun onResponse(
                call: Call<SingleResponse>,
                response: Response<SingleResponse>
            ) {
                if (response.code() == 200) {
                    val restResponse: SingleResponse = response.body()!!
                    if (restResponse.status == 1) {
                        dismissLoadingProgress()
                        val i =Intent(this@ActOrderDetail,ActDashBoard::class.java)
                        setResult(200,i)
                        finish()
                    } else if (restResponse.status == 0) {
                        dismissLoadingProgress()
                        alertErrorOrValidationDialog(
                            this@ActOrderDetail,
                            restResponse.message
                        )
                    }
                } else {
                    val error = JSONObject(response.errorBody()!!.string())
                    dismissLoadingProgress()
                    alertErrorOrValidationDialog(
                        this@ActOrderDetail,
                        error.getString("message")
                    )
                }
            }

            override fun onFailure(call: Call<SingleResponse>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    this@ActOrderDetail,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }


    @SuppressLint("SetTextI18n")
    private fun setFoodDetailData(response: OrderDetailResponse) {
        if (response.data!!.size > 0) {
            for (i in 0 until response.data.size) {
                OrderTotal += response.data[i].itemPrice!!.toDouble() * response.data[i].qty!!.toInt()
            }

            setFoodCategoryAdaptor(response.data)
        }

        btnAssignOrder?.setOnClickListener {
            if (response.orderType == "1") {


                if (orderStatus == 1) {
                    val hashMap = HashMap<String, String>()
                    hashMap["order_id"] = orderId
                    hashMap["status"] = "2"
                    hashMap["user_id"] =
                        SharePreference.getStringPref(this@ActOrderDetail, userId).toString()
                    callUpdateOrder(hashMap)

                } else if (orderStatus == 2) {
                    openGetDriverList()

                }
            }else if(response.orderType=="2")
            {

                if (orderStatus == 1) {
                    val hashMap = HashMap<String, String>()
                    hashMap["order_id"] = orderId
                    hashMap["status"] = "2"
                    hashMap["user_id"] =
                        SharePreference.getStringPref(this@ActOrderDetail, userId).toString()
                    callUpdateOrder(hashMap)

                }
            }
        }

        if (response.orderType == "2") {
            cvDeliveryAddress.visibility = View.GONE
            cvDriverInformation.visibility = View.GONE
            if (response.summery!!.promocode == null) {
                rlDiscount.visibility = View.GONE
                if (response.summery.orderNotes == null) {
                    tvNotes.text = ""
                    cvOrderNote.visibility = View.GONE
                } else {
                    cvOrderNote.visibility = View.VISIBLE
                    tvNotes.text = response.summery.orderNotes
                }
                if (response.deliveryAddress != null) {
                    tvOrderAddress.text = response.deliveryAddress
                    edLandmark.text = response.landmark
                    edBuilding.text = response.building
                }

                when (orderStatus) {
                    1 -> {
                        tvOrderStatusText.text =resources.getString(R.string.accept_)

                    }
                    2 -> {
                        tvOrderStatusText.text =resources.getString(R.string.picked_up)

                    }
                    else -> {
                        btnAssignOrder?.visibility = View.GONE
                        btnOrderCancelled?.visibility = View.GONE
                    }
                }

                tvOrderTotalPrice.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    OrderTotal
                )
                tvOrderTaxPrice.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    response.summery.tax!!.toDouble()
                )
                tvOrderDeliveryCharge.text = getCurrency(this@ActOrderDetail) + "0.00"

                val getTex: Double = (OrderTotal * response.summery.tax.toDouble()) / 100.toDouble()
                tvTitleTex.text = "Tax (${response.summery.tax}%)"

                tvOrderTaxPrice.text =
                    getCurrency(this@ActOrderDetail) + String.format(Locale.US, "%,.02f", getTex)
                val totalprice = OrderTotal + getTex + 0.00
                tvOrderTotalCharge.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    totalprice
                )
            } else {
                rlDiscount.visibility = View.VISIBLE
                if (response.summery.orderNotes == null) {
                    tvNotes.text = ""
                    cvOrderNote.visibility = View.GONE
                } else {
                    cvOrderNote.visibility = View.VISIBLE
                    tvNotes.text = response.summery.orderNotes
                }

                if (response.deliveryAddress != null) {
                    tvOrderAddress.text = response.deliveryAddress
                    edLandmark.text = response.landmark
                    edBuilding.text = response.building
                }

                tvOrderTotalPrice.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    OrderTotal
                )
                tvOrderTaxPrice.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    OrderTotal
                )
                tvOrderDeliveryCharge.text = getCurrency(this@ActOrderDetail) + "0.00"

                val getTex: Double =
                    (OrderTotal * response.summery.tax!!.toDouble()) / 100.toDouble()
                tvTitleTex.text = "Tax (${response.summery.tax}%)"
                tvOrderTaxPrice.text =
                    getCurrency(this@ActOrderDetail) + String.format(Locale.US, "%,.02f", getTex)

                tvDiscountOffer.text = "-" + getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    response.summery.discountAmount!!.toDouble()
                )
                tvPromoCodeApply.text = response.summery.promocode.toString()

                val subtotal = OrderTotal - response.summery.discountAmount.toDouble()
                val totalprice = subtotal + getTex + 0.00
                tvOrderTotalCharge.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    totalprice
                )
            }
        } else {

            when (orderStatus) {
                1 -> {
                    tvOrderStatusText.text = resources.getString(R.string.accept_)
                }
                2 -> {
                    tvOrderStatusText.text = resources.getString(R.string.assign_to_driver)
                }
                3 -> {
                    tvOrderStatusText.text =resources.getString(R.string.delivered)
                }
                else -> {
                    btnAssignOrder?.visibility = View.GONE
                    btnOrderCancelled?.visibility = View.GONE
                }
            }
            if (response.pincode != null) {
                edPinCode.text = response.pincode.toString()
            } else {
                edPinCode.text = ""
            }


            cvDeliveryAddress.visibility = View.VISIBLE
            if (intent.getStringExtra("order_status")!! == "3" || intent.getStringExtra("order_status")!! == "4"
            ) {
                cvDriverInformation.visibility = View.VISIBLE
                llCall.setOnClickListener {
                    //if(response.getMobile()!=null){
                    val call: Uri = Uri.parse("tel:${response.summery!!.driverMobile}")
                    val surf = Intent(Intent.ACTION_DIAL, call)
                    startActivity(surf)
                    //}
                }
                tvUserName.text = response.summery!!.driverName

                Glide.with(this@ActOrderDetail).load(response.summery.driverProfileImage)
                    .placeholder(
                        ResourcesCompat.getDrawable(resources, R.drawable.ic_placeholder, null)
                    ).centerCrop().into(ivUserDetail)
            } else {
                cvDriverInformation.visibility = View.GONE
            }

            if (response.summery!!.promocode == null) {
                rlDiscount.visibility = View.GONE
                if (response.summery.orderNotes == null) {
                    tvNotes.text = ""
                    cvOrderNote.visibility = View.GONE
                } else {
                    cvOrderNote.visibility = View.VISIBLE
                    tvNotes.text = response.summery.orderNotes
                }
                if (response.deliveryAddress != null) {
                    tvOrderAddress.text = response.deliveryAddress
                    edLandmark.text = response.landmark
                    edBuilding.text = response.building
                }
                tvOrderTotalPrice.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    OrderTotal
                )
                tvOrderTaxPrice.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    response.summery.tax!!.toDouble()
                )
                tvOrderDeliveryCharge.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US, "%,.02f", response.summery.deliveryCharge!!.toDouble()
                )

                val getTex: Double = (OrderTotal * response.summery.tax.toDouble()) / 100.toDouble()
                tvTitleTex.text = "Tax (${response.summery.tax}%)"
                tvOrderTaxPrice.text =
                    getCurrency(this@ActOrderDetail) + String.format(Locale.US, "%,.02f", getTex)
                val totalprice = OrderTotal + getTex + response.summery.deliveryCharge.toDouble()
                tvOrderTotalCharge.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    totalprice
                )
            } else {
                rlDiscount.visibility = View.VISIBLE
                if (response.summery.orderNotes == null) {
                    tvNotes.text = ""
                    cvOrderNote.visibility = View.GONE
                } else {
                    cvOrderNote.visibility = View.VISIBLE
                    tvNotes.text = response.summery.orderNotes
                }
                if (response.deliveryAddress != null) {
                    tvOrderAddress.text = response.deliveryAddress
                    edLandmark.text = response.landmark
                    edBuilding.text = response.building
                }
                tvOrderTotalPrice.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    OrderTotal
                )
                tvOrderTaxPrice.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    response.summery.tax!!.toDouble()
                )
                tvOrderDeliveryCharge.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US, "%,.02f", response.summery.deliveryCharge!!.toDouble()
                )

                val getTex: Double = (OrderTotal * response.summery.tax.toDouble()) / 100
                tvTitleTex.text = "Tax (${response.summery.tax}%)"
                tvOrderTaxPrice.text =
                    getCurrency(this@ActOrderDetail) + String.format(Locale.US, "%,.02f", getTex)

                tvDiscountOffer.text = "-" + getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    response.summery.discountAmount!!.toFloat()
                )
                tvPromoCodeApply.text = response.summery.promocode.toString()

                val subtotal = OrderTotal - response.summery.discountAmount.toDouble()
                val totalprice = subtotal + getTex + response.summery.deliveryCharge.toFloat()
                tvOrderTotalCharge.text = getCurrency(this@ActOrderDetail) + String.format(
                    Locale.US,
                    "%,.02f",
                    totalprice
                )
            }
        }

    }


    private fun setFoodCategoryAdaptor(orderHistoryList: ArrayList<OrderDataItem>) {
        val orderHistoryAdapter =
            object : BaseAdaptor<OrderDataItem>(this@ActOrderDetail, orderHistoryList) {
                @SuppressLint("SetTextI18n", "NewApi")
                override fun onBindData(
                    holder: RecyclerView.ViewHolder?,
                    `val`: OrderDataItem,
                    position: Int
                ) {

                    val tvOrderFoodName: TextView = holder!!.itemView.findViewById(R.id.tvFoodName)
                    val ivFoodItem: ImageView = holder.itemView.findViewById(R.id.ivFoodCart)
                    val tvPrice: TextView = holder.itemView.findViewById(R.id.tvPrice)
                    val tvQtyNumber: TextView = holder.itemView.findViewById(R.id.tvItemQty)
                    val tvWeight: TextView = holder.itemView.findViewById(R.id.tvWeight)

                    Glide.with(this@ActOrderDetail)
                        .load(orderHistoryList[position].itemimage)
                        .into(ivFoodItem)


                    tvOrderFoodName.text = orderHistoryList[position].itemName

                    val price =
                        orderHistoryList[position].itemPrice!!.toDouble() * orderHistoryList[position].qty!!.toInt()
                    tvPrice.text =
                        getCurrancy(this@ActOrderDetail) + String.format(Locale.US, "%,.2f", price)
                    tvQtyNumber.text = orderHistoryList[position].qty.toString()
                    tvWeight.text=orderHistoryList[position].weight.toString()
                    Glide.with(this@ActOrderDetail).load(orderHistoryList[position].itemimage)
                        .placeholder(
                            ResourcesCompat.getDrawable(
                                resources,
                                R.drawable.ic_placeholder,
                                null
                            )
                        )
                        .into(ivFoodItem)

                    val rlFood: RelativeLayout = holder.itemView.findViewById(R.id.rlFood)

                    when (position % 5) {
                        0 -> {
                            rlFood.backgroundTintList = ColorStateList.valueOf(
                                ResourcesCompat.getColor(
                                    resources,
                                    R.color.color1,
                                    null
                                )
                            )
                        }
                        1 -> {
                            rlFood.backgroundTintList = ColorStateList.valueOf(
                                ResourcesCompat.getColor(
                                    resources,
                                    R.color.color2,
                                    null
                                )
                            )
                        }
                        2 -> {
                            rlFood.backgroundTintList = ColorStateList.valueOf(
                                ResourcesCompat.getColor(
                                    resources,
                                    R.color.color3,
                                    null
                                )
                            )
                        }
                        3 -> {
                            rlFood.backgroundTintList = ColorStateList.valueOf(
                                ResourcesCompat.getColor(
                                    resources,
                                    R.color.color4,
                                    null
                                )
                            )
                        }
                        4 -> {
                            rlFood.backgroundTintList = ColorStateList.valueOf(
                                ResourcesCompat.getColor(
                                    resources,
                                    R.color.color5,
                                    null
                                )
                            )
                        }
                    }


                }

                override fun setItemLayout(): Int {
                    return R.layout.row_orderitemsummary
                }

            }
        rvOrderItemFood.adapter = orderHistoryAdapter
        rvOrderItemFood.layoutManager = LinearLayoutManager(this@ActOrderDetail)
        rvOrderItemFood.itemAnimator = DefaultItemAnimator()
        rvOrderItemFood.isNestedScrollingEnabled = true
    }

}