import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.util.Log
import android.view.View
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.grocery.owner.R
import com.grocery.owner.activity.ActDashBoard
import com.grocery.owner.activity.ActOrderDetail
import com.grocery.owner.api.ApiClient
import com.grocery.owner.base.BaseAdaptor
import com.grocery.owner.base.BaseFragmnet
import com.grocery.owner.model.HomeModel
import com.grocery.owner.model.TodayordersItem
import com.grocery.owner.utils.Common
import com.grocery.owner.utils.Common.alertErrorOrValidationDialog
import com.grocery.owner.utils.Common.dismissLoadingProgress
import com.grocery.owner.utils.Common.getCurrentLanguage
import com.grocery.owner.utils.Common.isCheckNetwork
import com.grocery.owner.utils.Common.showLoadingProgress
import com.grocery.owner.utils.SharePreference
import com.grocery.owner.utils.SharePreference.Companion.getStringPref
import com.grocery.owner.utils.SharePreference.Companion.isCurrancy
import com.grocery.owner.utils.SharePreference.Companion.setStringPref
import com.google.gson.Gson
import kotlinx.android.synthetic.main.frag_home.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.HashMap

class FragHome : BaseFragmnet() {
    override fun setView(): Int = R.layout.frag_home

    override fun Init(view: View) {
        getCurrentLanguage(requireActivity(), false)

        if (isCheckNetwork(requireContext())) {
            callHomeApi()
        } else {
            alertErrorOrValidationDialog(requireActivity(), getString(R.string.no_internet))
        }
        ivMenu.setOnClickListener {
            (activity as ActDashBoard?)?.onDrawerToggle()
        }
    }


    private fun callHomeApi() {
        showLoadingProgress(activity!!)
        val map = HashMap<String, String>()
        map["user_id"] = getStringPref(activity!!, SharePreference.userId)!!
        val call = ApiClient.getClient.getHomeDetail(map)
        call.enqueue(object : Callback<HomeModel> {
            override fun onResponse(
                call: Call<HomeModel>,
                response: Response<HomeModel>
            ) {
                if (response.code() == 200) {
                    homeLayout?.visibility = View.VISIBLE
                    dismissLoadingProgress()
                    val restResponse: HomeModel = response.body()!!
                    setStringPref(requireActivity(), isCurrancy, restResponse.currency.toString())
                    setupHome(restResponse)

                } else {
                    dismissLoadingProgress()
                    alertErrorOrValidationDialog(requireActivity(), getString(R.string.error_msg))
                }
            }


            override fun onFailure(call: Call<HomeModel>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    activity!!,
                    resources.getString(R.string.error_msg)
                )

                Log.e("error", t.message.toString())
            }
        })
    }


    override fun onResume() {
        super.onResume()
        getCurrentLanguage(requireActivity(), false)

    }

    @SuppressLint("NewApi")
    private fun setupHome(homeData: HomeModel) {
        tvTotalEarning.text = getStringPref(requireActivity(), isCurrancy) + homeData.earning
        tvTotalOrders.text = homeData.totalOrders.toString()
        tvLatestOrder.text = homeData.latestOrder.toString()
        tvCancelOrders?.text = homeData.cancelledOrder.toString()
        val current = LocalDateTime.now()

        val formatter = DateTimeFormatter.ofPattern("MMM d, yyyy ")

        tvDate.text = formatter.format(current)
        if (homeData.todayorders?.size ?: 0 > 0) {
            rvLatestOrder.visibility = View.VISIBLE
            tvNoDataFound.visibility = View.GONE
            homeData.todayorders?.let { setFoodCategoryAdaptor(it) }
        } else {
            rvLatestOrder.visibility = View.GONE
            tvNoDataFound.visibility = View.VISIBLE
        }
    }


    private fun setFoodCategoryAdaptor(
        orderHistoryList: ArrayList<TodayordersItem>
    ) {
        val orderHistoryAdapter =
            object : BaseAdaptor<TodayordersItem>(activity!!, orderHistoryList) {
                @SuppressLint("SetTextI18n", "NewApi")
                override fun onBindData(
                    holder: RecyclerView.ViewHolder?,
                    `val`: TodayordersItem,
                    position: Int
                ) {
                    val tvOrderNumber: TextView = holder!!.itemView.findViewById(R.id.tvOrderNumber)
                    val tvPrice: TextView = holder.itemView.findViewById(R.id.tvPayment)
                    val rlOrder: RelativeLayout = holder.itemView.findViewById(R.id.rlOrder)
                    val tvOrderStatus: TextView = holder.itemView.findViewById(R.id.tvOrderStatus)
                    val tvPaymentType: TextView = holder.itemView.findViewById(R.id.tvPaymentType)
                    val tvOrderDate: TextView = holder.itemView.findViewById(R.id.tvOrderDate)

                    tvOrderNumber.text = orderHistoryList[position].orderNumber
                    tvPrice.text = getStringPref(
                        activity!!,
                        isCurrancy
                    ) + String.format(
                        Locale.US,
                        "%,.2f",
                        orderHistoryList[position].totalPrice?.toDouble()
                    )

                    tvOrderDate.text = orderHistoryList[position].date?.let { Common.getDate(it) }

                    if (orderHistoryList[position].status == "5") {
                        rlOrder.backgroundTintList = ColorStateList.valueOf(
                            ResourcesCompat.getColor(
                                resources,
                                R.color.status1,
                                null
                            )
                        )
                        tvOrderStatus.text = resources.getString(R.string.order_cancelled_you)
                    } else if (orderHistoryList[position].status == "6") {
                        rlOrder.backgroundTintList = ColorStateList.valueOf(
                            ResourcesCompat.getColor(
                                resources,
                                R.color.status1,
                                null
                            )
                        )
                        tvOrderStatus.text = resources.getString(R.string.order_cancelled_admin)
                    } else {
                        if (orderHistoryList[position].orderType == "1") {
                            when (orderHistoryList[position].status) {
                                "1" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status1,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.order_place)
                                }
                                "2" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status2,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.order_ready)
                                }
                                "3" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status3,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.on_the_way)
                                }
                                "4" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status4,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text =
                                        resources.getString(R.string.order_delivered)
                                }
                            }
                        } else {
                            when (orderHistoryList[position].status) {
                                "1" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status1,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.order_place)
                                }
                                "2" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status2,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.order_ready)
                                }
                                "4" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status3,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text =
                                        resources.getString(R.string.order_delivered)
                                }
                            }
                        }
                    }


                    /*     when {
                             orderHistoryList.get(position).status.equals("1") -> {
                                 tvOrderStatus.text = "Order Placed"
                             }
                             orderHistoryList.get(position).status.equals("2") -> {
                                 tvOrderStatus.text = "Order Preparing"
                             }
                             orderHistoryList.get(position).status.equals("3") -> {
                                 tvOrderStatus.text = "Order on the way"
                             }
                             orderHistoryList.get(position).status.equals("4") -> {
                                 tvOrderStatus.text = "Order Delivered"
                             }
                             orderHistoryList[position].status.equals("5") -> {
                                 tvOrderStatus.text = "Order Cancelled"
                             }
                         }*/

                    if (orderHistoryList.get(position).paymentType!!.toInt() == 0) {
                        tvPaymentType.text = resources.getString(R.string.pay_by_cash)
                    } else {
                        tvPaymentType.text =resources.getString(R.string.razorpay)
                    }

                    // tvOrderDate.text=Common.getDate(orderHistoryList.get(position).getDate()!!)


                    holder.itemView.setOnClickListener {
                        startActivityForResult(
                            Intent(
                                activity!!,
                                ActOrderDetail::class.java
                            ).putExtra("order_id", orderHistoryList[position].id.toString())
                                .putExtra(
                                    "order_status",
                                    orderHistoryList[position].status.toString()
                                ), 200
                        )
                    }
                }

                override fun setItemLayout(): Int {
                    return R.layout.row_orderdelivery
                }


            }
        rvLatestOrder.adapter = orderHistoryAdapter
        rvLatestOrder.layoutManager = LinearLayoutManager(activity!!)
        rvLatestOrder.itemAnimator = DefaultItemAnimator()
        rvLatestOrder.isNestedScrollingEnabled = true
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == 200) {
            if (isCheckNetwork(requireContext())) {
                callHomeApi()
            } else {
                alertErrorOrValidationDialog(requireActivity(), getString(R.string.no_internet))
            }
        }

    }
}