package com.grocery.owner.fragments

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.grocery.owner.R
import com.grocery.owner.activity.ActDashBoard
import com.grocery.owner.activity.ActOrderDetail
import com.grocery.owner.api.ApiClient
import com.grocery.owner.base.BaseAdaptor
import com.grocery.owner.base.BaseFragmnet
import com.grocery.owner.model.HistoryResponse
import com.grocery.owner.model.OrdersItem
import com.grocery.owner.utils.Common.alertErrorOrValidationDialog
import com.grocery.owner.utils.Common.dismissLoadingProgress
import com.grocery.owner.utils.Common.getCurrency
import com.grocery.owner.utils.Common.getCurrentLanguage
import com.grocery.owner.utils.Common.getDate
import com.grocery.owner.utils.Common.isCheckNetwork
import com.grocery.owner.utils.Common.showLoadingProgress
import com.grocery.owner.utils.SharePreference
import com.grocery.owner.utils.SharePreference.Companion.userId
import kotlinx.android.synthetic.main.frag_my_orders.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class FragMyOrders : BaseFragmnet() {

    var orderHistoryList = ArrayList<OrdersItem>()
    var orderHistoryAdaptor: BaseAdaptor<OrdersItem>? = null
    override fun setView(): Int = R.layout.frag_my_orders

    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    override fun Init(view: View) {
        getCurrentLanguage(requireActivity(), false)

        ivMenu.setOnClickListener {
            (activity as ActDashBoard?)?.onDrawerToggle()
        }
        getCurrentLanguage(activity!!, false)
        setOrderHistoryAdapter(orderHistoryList)
        if (isCheckNetwork(activity!!)) {
            callApiOrderHistory("", "")
        } else {
            alertErrorOrValidationDialog(activity!!, resources.getString(R.string.no_internet))
        }
        ivFilter?.setOnClickListener {
            openFilter()
        }
    }


    private fun openFilter() {
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        val lp = WindowManager.LayoutParams()
        lp.windowAnimations = R.style.DialogAnimation
        dialog.window!!.attributes = lp
        dialog.setContentView(R.layout.dlg_date_filter)
        dialog.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val ivCancel = dialog.findViewById<ImageView>(R.id.ivCancel)
        val btnSubmit = dialog.findViewById<TextView>(R.id.btnSubmit)
        val tvStartDate = dialog.findViewById<TextView>(R.id.tvStartDate)
        val tvEndDate = dialog.findViewById<TextView>(R.id.tvEndDate)


        btnSubmit.setOnClickListener {

            when {

                tvStartDate.text.isEmpty() -> {
                    alertErrorOrValidationDialog(requireActivity(), resources.getString(R.string.start_date_alert))
                }
                tvEndDate.text.isEmpty() -> {
                    alertErrorOrValidationDialog(requireActivity(),resources.getString(R.string.end_date_alert))
                }
                else -> {
                    dialog.dismiss()
                        callApiOrderHistory(tvStartDate.text.toString(), tvEndDate.text.toString())
                }
            }
        }

        tvStartDate.setOnClickListener {
            getDate(tvStartDate)
        }
        tvEndDate.setOnClickListener {
            getDate(tvEndDate)

        }
        ivCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun getDate(textView: TextView) {
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)
        var date = ""

        val dpd = DatePickerDialog(
            requireContext(),
            { _, year, monthOfYear, dayOfMonth ->

                // Display Selected date in textbox

                val formatter = SimpleDateFormat("dd-MM-yyyy", Locale.US)
                val newDate = Calendar.getInstance()
                newDate[year, monthOfYear] = dayOfMonth

                date = formatter.format(newDate.time)
                textView.text = date
            },
            year,
            month,
            day
        )

        dpd.show()


    }

    override fun onResume() {
        super.onResume()
        getCurrentLanguage(requireActivity(), false)

    }

    private fun callApiOrderHistory(startDate: String, endDate: String) {
        showLoadingProgress(activity!!)
        val map = HashMap<String, String>()
        map["user_id"] = SharePreference.getStringPref(activity!!, userId)!!
        map["start_date"] = startDate
        map["end_date"] = endDate
        val call = ApiClient.getClient.orderHistory(map)
        call.enqueue(object : Callback<HistoryResponse> {
            override fun onResponse(
                call: Call<HistoryResponse>,
                response: Response<HistoryResponse>
            ) {
                if (response.code() == 200) {
                    val restResponce: HistoryResponse = response.body()!!
                    if (restResponce.status == 1) {
                        dismissLoadingProgress()
                        tvNoDataFound?.visibility = View.GONE
                        rvOrderHistory?.visibility = View.VISIBLE
                        val orderHistoryResponse: ArrayList<OrdersItem> = restResponce.orders!!
                        if (orderHistoryResponse.isNullOrEmpty()) {
                            tvNoDataFound?.visibility = View.VISIBLE
                            rvOrderHistory?.visibility = View.GONE
                        } else {
                            if (orderHistoryResponse.size > 0) {
                                orderHistoryList.clear()
                                tvNoDataFound?.visibility = View.GONE
                                rvOrderHistory?.visibility = View.VISIBLE
                                for (i in 0 until orderHistoryResponse.size) {
                                    val ordersItem = orderHistoryResponse[i]
                                    orderHistoryList.add(ordersItem)
                                }
                                orderHistoryAdaptor!!.notifyDataSetChanged()
                            } else {
                                tvNoDataFound?.visibility = View.VISIBLE
                                rvOrderHistory?.visibility = View.GONE
                            }

                        }
                    } else if (restResponce.status == 0) {
                        tvNoDataFound?.visibility = View.GONE
                        rvOrderHistory?.visibility = View.VISIBLE
                        dismissLoadingProgress()
                        alertErrorOrValidationDialog(activity!!, restResponce.message)
                    }
                }
            }

            override fun onFailure(call: Call<HistoryResponse>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(activity!!, resources.getString(R.string.error_msg))
            }
        })
    }


    private fun setOrderHistoryAdapter(orderHistoryList: ArrayList<OrdersItem>) {
        orderHistoryAdaptor =
            object : BaseAdaptor<OrdersItem>(requireActivity(), orderHistoryList) {
                @SuppressLint("SetTextI18n", "NewApi", "UseCompatLoadingForDrawables")
                override fun onBindData(
                    holder: RecyclerView.ViewHolder?,
                    `val`: OrdersItem,
                    position: Int
                ) {
                    val tvOrderNumber: TextView = holder!!.itemView.findViewById(R.id.tvOrderNumber)
                    val tvPrice: TextView = holder.itemView.findViewById(R.id.tvPayment)
                    val tvOrderStatus: TextView = holder.itemView.findViewById(R.id.tvOrderStatus)
                    val tvPaymentType: TextView = holder.itemView.findViewById(R.id.tvPaymentType)
                    val tvOrderDate: TextView = holder.itemView.findViewById(R.id.tvOrderDate)
                    val tvOrderType: TextView = holder.itemView.findViewById(R.id.tvOrderType)
                    val rlOrder: RelativeLayout = holder.itemView.findViewById(R.id.rlOrder)

                    tvOrderNumber.text = orderHistoryList[position].orderNumber.toString()
                    tvPrice.text = getCurrency(requireActivity()) + String.format(
                        Locale.US,
                        "%,.2f",
                        orderHistoryList[position].totalPrice!!.toDouble()
                    )

                    if (orderHistoryList[position].orderType == "2") {
                        tvOrderType.text =resources.getString(R.string.pickup)
                    } else if (orderHistoryList[position].orderType == "1") {
                        tvOrderType.text =resources.getString(R.string.delivery)
                    }

                    if (orderHistoryList[position].date == null) {
                        tvOrderDate.text = ""
                    } else {
                        tvOrderDate.text = getDate(orderHistoryList[position].date!!)
                    }

                    when {
                        orderHistoryList[position].paymentType!!.toInt() == 0 -> {
                            tvPaymentType.text = resources.getString(R.string.cash)
                        }
                        orderHistoryList[position].paymentType!!.toInt() == 1 -> {
                            tvPaymentType.text =resources.getString(R.string.razorpay)
                        }
                        orderHistoryList[position].paymentType!!.toInt() == 2 -> {
                            tvPaymentType.text =resources.getString(R.string.stripe)
                        }
                        else -> {
                            tvPaymentType.text = resources.getString(R.string.wallet)
                        }
                    }

                    if (orderHistoryList[position].status == "5") {
                        rlOrder.backgroundTintList = ColorStateList.valueOf(
                            ResourcesCompat.getColor(
                                resources,
                                R.color.status1,
                                null
                            )
                        )
                        tvOrderStatus.text = resources.getString(R.string.order_cancelled_you)
                    } else if (orderHistoryList[position].status == "6") {
                        rlOrder.backgroundTintList = ColorStateList.valueOf(
                            ResourcesCompat.getColor(
                                resources,
                                R.color.status1,
                                null
                            )
                        )
                        tvOrderStatus.text = resources.getString(R.string.order_cancelled_admin)
                    } else {
                        if (orderHistoryList[position].orderType == "1") {
                            when (orderHistoryList[position].status) {
                                "1" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status1,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.order_place)
                                }
                                "2" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status2,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.order_ready)
                                }
                                "3" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status3,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.on_the_way)
                                }
                                "4" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status4,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text =
                                        resources.getString(R.string.order_delivered)
                                }
                            }
                        } else {
                            when (orderHistoryList[position].status) {
                                "1" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status1,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.order_place)
                                }
                                "2" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status2,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text = resources.getString(R.string.order_ready)
                                }
                                "4" -> {
                                    rlOrder.backgroundTintList = ColorStateList.valueOf(
                                        ResourcesCompat.getColor(
                                            resources,
                                            R.color.status3,
                                            null
                                        )
                                    )
                                    tvOrderStatus.text =
                                        resources.getString(R.string.order_delivered)
                                }
                            }
                        }
                    }



                    holder.itemView.setOnClickListener {
                        startActivityForResult(
                            Intent(
                                requireActivity(),
                                ActOrderDetail::class.java
                            ).putExtra("order_id", orderHistoryList[position].id.toString())
                                .putExtra(
                                    "order_status",
                                    orderHistoryList[position].status.toString()
                                )
                       ,200 )
                    }
                }

                override fun setItemLayout(): Int {
                    return R.layout.row_orderdelivery
                }

            }
        rvOrderHistory.adapter = orderHistoryAdaptor
        rvOrderHistory.layoutManager = LinearLayoutManager(requireActivity())
        rvOrderHistory.itemAnimator = DefaultItemAnimator()
        rvOrderHistory.isNestedScrollingEnabled = true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(resultCode==200)
        {
            if (isCheckNetwork(activity!!)) {
                callApiOrderHistory("", "")
            } else {
                alertErrorOrValidationDialog(activity!!, resources.getString(R.string.no_internet))
            }
        }
    }
}