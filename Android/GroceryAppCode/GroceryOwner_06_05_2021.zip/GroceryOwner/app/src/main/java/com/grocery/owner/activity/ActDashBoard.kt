package com.grocery.owner.activity

import FragHome
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.grocery.owner.R
import com.grocery.owner.base.BaseActivity
import com.grocery.owner.fragments.FragMyOrders
import com.grocery.owner.fragments.FragSettings
import com.grocery.owner.utils.Common
import com.grocery.owner.utils.SharePreference
import com.grocery.owner.utils.SharePreference.Companion.getStringPref
import kotlinx.android.synthetic.main.dlg_logout.view.*
import kotlinx.android.synthetic.main.layout_nevheader.*


open class ActDashBoard : BaseActivity() {
    var drawer_layout: DrawerLayout? = null
    var nav_view: LinearLayout? = null
    var tvName: TextView?=null
    var ivProfile: ImageView?=null
    var temp=1
    override fun setLayout(): Int = R.layout.act_dash_board

    override fun InitView() {
        Common.getCurrentLanguage(this@ActDashBoard, false)

        drawer_layout = findViewById(R.id.drawer_layout)
        nav_view = findViewById(R.id.nav_view)
        tvName=drawer_layout!!.findViewById(R.id.tv_NevProfileName)!!
        ivProfile=drawer_layout!!.findViewById(R.id.ivProfile)!!

        if(getStringPref(this@ActDashBoard, SharePreference.SELECTED_LANGUAGE).equals(resources.getString(R.string.language_hindi))){
            ivBackCategory.rotation= 180F
            ivBackLogOut.rotation= 180F
            ivBackHome.rotation= 180F
            ivBackOrder.rotation= 180F
        }else{
            ivBackCategory.rotation= 0F
            ivBackLogOut.rotation= 0F
            ivBackHome.rotation= 0F
            ivBackOrder.rotation= 0F
        }
        val fragHome = FragHome()
        val transaction = supportFragmentManager.beginTransaction()
            .replace(R.id.FramFragment, fragHome)
        transaction.commit()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }

    fun onClick(v: View?) {
        when (v!!.id) {
            R.id.rl_home -> {
                drawer_layout!!.closeDrawers()
                if (temp != 1) {
                    setFragment(1)
                    temp = 1
                }
            }
            R.id.rl_orderhistory -> {
                drawer_layout!!.closeDrawers()
                if (temp != 2) {
                    setFragment(2)
                    temp = 2
                }
            }


            R.id.rlSettings -> {
                drawer_layout!!.closeDrawers()
                if (temp != 3) {
                    setFragment(3)
                    temp = 4
                }
            }
            R.id.rlLogOut -> {
                drawer_layout!!.closeDrawers()
                setFragment(4)
            }
        }
    }


    open fun onDrawerToggle() {
        drawer_layout!!.openDrawer(nav_view!!)
    }
    private fun setFragment(pos: Int){
        when (pos){
            1 -> {
                replaceFragment(FragHome())
            }
            2 -> {
                replaceFragment(FragMyOrders())
            }
            3 -> {
                replaceFragment(FragSettings())
            }
            4 -> {
                alertLogOutDialog()
            }
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        val fragmentManager: FragmentManager = supportFragmentManager
        val fragmentTransaction: FragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.FramFragment, fragment)
        fragmentTransaction.addToBackStack(fragment.toString())
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
        //fragmentTransaction.commit()
        fragmentTransaction.commitAllowingStateLoss()
    }



    private fun alertLogOutDialog() {
        var dialog: Dialog? = null
        try {
            if (dialog != null) {
                dialog.dismiss()
                dialog = null
            }
            dialog = Dialog(this@ActDashBoard, R.style.AppCompatAlertDialogStyleBig)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT
            );
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCancelable(false)
            val mInflater = LayoutInflater.from(this@ActDashBoard)
            val mView = mInflater.inflate(R.layout.dlg_logout, null, false)

            val finalDialog: Dialog = dialog
            mView.tvLogout.setOnClickListener {
                finalDialog.dismiss()
                Common.setLogout(this@ActDashBoard)

            }
            mView.tvCancel.setOnClickListener {
                finalDialog.dismiss()
            }
            dialog.setContentView(mView)
            dialog.show()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }


    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(this@ActDashBoard, false)
    }

    override fun onPause() {
        super.onPause()
        Common.getCurrentLanguage(this@ActDashBoard, false)
    }

}